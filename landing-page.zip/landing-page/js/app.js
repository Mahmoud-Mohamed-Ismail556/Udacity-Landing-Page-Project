const allSections = document.querySelectorAll('section');//selecting all sections in html page
const ulElement = document.getElementById('navbar__list');//selecting ul element
let docFragment = document.createDocumentFragment();
allSections.forEach(function(section) {
    var liElement = document.createElement("li");//<li></li>
    var anchorElement = document.createElement("a");//<a></a>
    anchorElement.classList.add("menu__link");//<a class = "menu__link"></a>
    var textNode = document.createTextNode(section.dataset.nav);//selecting data-nav for every sections
    anchorElement.appendChild(textNode);//<a class = "menu__link">section1</a>
    anchorElement.href = "#" + section.id;//<a class = "menu__link href = "#section 1">section1</a>
    liElement.appendChild(anchorElement);//<li><a class = "menu__link href = "#section 1">section1</a></li>
    docFragment.appendChild(liElement);
});
ulElement.appendChild(docFragment);

//when scrolling in the window the targeted section will have a red border
window.addEventListener('scroll' ,function(section) {
    allSections.forEach(function(section) {
//return how many pixels the section is far from the top
        let sectionTopPosition = Math.floor(section.getBoundingClientRect().top);
//when the targeted section appear on the window while scrolling your active class will be added and it will be removed if not
        if (sectionTopPosition < 400 && sectionTopPosition >= -150) {
            section.classList.add('your-active-class');
            section.style.cssText = "border: 2px solid red;";
      } else {
            section.classList.remove('your-active-class');
            section.style.cssText = "background-color: linear-gradient(0deg, rgba(255,255,255,.1) 0%, rgba(255,255,255,.2) 100%)";
             }
            });
});


//smooth scroll by using scrollintoview
document.querySelectorAll('a[href^="#"]').forEach(elem => {//getting all anchor elements which contain #
  elem.addEventListener('click', prevdefault => {
      prevdefault.preventDefault();//prevent default scrolling.
      document.querySelector(elem.getAttribute('href')).scrollIntoView({//href value is the same value as section.id 
          behavior: 'smooth',
          offsetTop: 20
      });
  });
});






