# Landing Page Project

this project is about converting a static web page to a dynamic web page by using javascript.

languages used are HTML, CSS and Javascript.

you can get the maximum functionality by opening HTML then start by clicking on navigation bar.

also you can scroll down to watch the change to every section.

by looking at css and javascript files you can watch the step by step coding.


